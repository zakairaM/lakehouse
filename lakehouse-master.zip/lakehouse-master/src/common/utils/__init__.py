# Utility functions

